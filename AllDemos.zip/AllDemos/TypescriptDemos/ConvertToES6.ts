let y:string = "Hi";

function Addition(x:any,y:any){
    return x + y;
}