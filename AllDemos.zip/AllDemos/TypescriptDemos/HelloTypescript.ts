var x =100;  // Type Inference
//x = "Hello !";
var s:string; // Type Annotation
s = "Hello !";

var b:boolean;
var o:object;
var n:number;
var anyVar;// implicitly of type any
anyVar = [10,20,30];
anyVar = {name:'Siemens'};
anyVar = true;

if(true){
    let blockedScoped:boolean;
    blockedScoped = true;
    {
        console.log(blockedScoped)
    }   
}


const PI = 3.14;

const company = {name:'Siemens'};
company.name = "Accenture";
console.log(company.name);

// Functions

// function Add(x:number,y:number):number|string{
//     if(x < 0){
//         return 'X should be greater than 0'
//     }
//     return x + y;
// }

// var result:number|string = Add(10,20)

// OR Function as expression

var Add = function(x:number,y:number):number{
    return x + y;
}

// Arrow Functions

var Square = (x)=>{
    return x * x;
}

// OR

var EnhancedSquare = x => x * x;

function Emp(){
    this.salary = 500000;   
    setTimeout(()=>console.log(this.salary)
    ,2000)
}
 
var e = new Emp();

// Parameters

// Optional Parameters
// function PrintBooks(author?:string,title?:string){
//     console.log(author,title);
// }

// PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way")

// Default Paramters
// function PrintBooks(author:string="Unknown",title:string="Unknown"){
//         console.log(author,title);
// }
// PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way")
// PrintBooks(undefined,"Some Title !");


// Rest Parameters
function PrintBooks(author:string,...titles:string[]){
        console.log(author,titles);
}

PrintBooks("Sachin Tendulkar","Playing It My Way");
PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");

// Arrays
var cars:string[] = ["BMW","AUDI","FERRARI"];

var moreCars:string[] = new Array("TATA","MAHINDRA","HONDA");

var allCars = [...cars,...moreCars,"TOYOTA"];// Spread Operator

cars[1] = "HYUNDAI";// this change does not reflect in allCars

console.log(allCars);

// Spread Operator with Objects (ES6)

var person = {name:'Sachin Tendulkar',age:45};

var player:any={...person,runs:50000};

// Destructuring (ES6) with arrays

//var first,second,third;
var [first,,second] = cars;

console.log(first,second);

// Destructuring (ES6) with objects

var age,runs,city;
({age,runs,city="Mumbai"} = player);


// Interfaces

// interface  IEmp{
//         name:string;
//         salary:number;   
//         id?:number;     
// }
// var emp:IEmp = {name:'Amit',
// salary:50000};

// class

class Car{
    // private id:number;
    name:string;
    speed:number;

    constructor(name:string="i10",speed:number=100){
            this.name = name;
            this.speed = speed;
    }

    accelerate():string{
        //console.log('The Car ' + this.name + ' is running at ' + this.speed + " kmph !");
       return (`The car ${this.name} is running at ${this.speed} kmph !`)
    }
}
// var carObj:Car =  new Car();
// carObj.accelerate();
class JamesBondCar extends Car{
        canFly:boolean;
        canSubmerge:boolean;
        constructor(name:string,speed:number,
            fly:boolean,submerge:boolean){
            super(name,speed);
            this.canFly = fly;
            this.canSubmerge = submerge;
        }
        accelerate():string{
            return super.accelerate()  + " Can It fly ?" + this.canFly;
        }
}
var jbc:JamesBondCar =new JamesBondCar("Aston Martin",700,true,true);
console.log(jbc.accelerate());


interface  IEmp{
    name:string;
    salary:number;   
    id?:number;   
    getSalary?():number;  
}
class CEmp implements IEmp{
    name:string;
    salary:number;   
    id:number;   
    getSalary(){
        return this.salary;
    }
}

class EnhancedCar{
    constructor(public name:string,public speed:number){

    }
}

// var c = new EnhancedCar()
