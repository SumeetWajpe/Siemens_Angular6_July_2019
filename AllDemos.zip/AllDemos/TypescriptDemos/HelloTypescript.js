var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a;
var x = 100; // Type Inference
//x = "Hello !";
var s; // Type Annotation
s = "Hello !";
var b;
var o;
var n;
var anyVar; // implicitly of type any
anyVar = [10, 20, 30];
anyVar = { name: 'Siemens' };
anyVar = true;
if (true) {
    var blockedScoped = void 0;
    blockedScoped = true;
    {
        console.log(blockedScoped);
    }
}
var PI = 3.14;
var company = { name: 'Siemens' };
company.name = "Accenture";
console.log(company.name);
// Functions
// function Add(x:number,y:number):number|string{
//     if(x < 0){
//         return 'X should be greater than 0'
//     }
//     return x + y;
// }
// var result:number|string = Add(10,20)
// OR Function as expression
var Add = function (x, y) {
    return x + y;
};
// Arrow Functions
var Square = function (x) {
    return x * x;
};
// OR
var EnhancedSquare = function (x) { return x * x; };
function Emp() {
    var _this = this;
    this.salary = 500000;
    setTimeout(function () { return console.log(_this.salary); }, 2000);
}
var e = new Emp();
// Parameters
// Optional Parameters
// function PrintBooks(author?:string,title?:string){
//     console.log(author,title);
// }
// PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way")
// Default Paramters
// function PrintBooks(author:string="Unknown",title:string="Unknown"){
//         console.log(author,title);
// }
// PrintBooks();
// PrintBooks("Sachin Tendulkar","Playing It My Way")
// PrintBooks(undefined,"Some Title !");
// Rest Parameters
function PrintBooks(author) {
    var titles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        titles[_i - 1] = arguments[_i];
    }
    console.log(author, titles);
}
PrintBooks("Sachin Tendulkar", "Playing It My Way");
PrintBooks("Dr. APJ Abdul Kalam", "India 2020", "Wings Of Fire");
// Arrays
var cars = ["BMW", "AUDI", "FERRARI"];
var moreCars = new Array("TATA", "MAHINDRA", "HONDA");
var allCars = cars.concat(moreCars, ["TOYOTA"]); // Spread Operator
cars[1] = "HYUNDAI"; // this change does not reflect in allCars
console.log(allCars);
// Spread Operator with Objects (ES6)
var person = { name: 'Sachin Tendulkar', age: 45 };
var player = __assign({}, person, { runs: 50000 });
// Destructuring (ES6) with arrays
//var first,second,third;
var first = cars[0], second = cars[2];
console.log(first, second);
// Destructuring (ES6) with objects
var age, runs, city;
(age = player.age, runs = player.runs, _a = player.city, city = _a === void 0 ? "Mumbai" : _a);
var emp = { name: 'Amit',
    salary: 50000 };
// class
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i10"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //console.log('The Car ' + this.name + ' is running at ' + this.speed + " kmph !");
        return ("The car " + this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// var carObj:Car =  new Car();
// carObj.accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, fly, submerge) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = fly;
        _this.canSubmerge = submerge;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can It fly ?" + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 700, true, true);
console.log(jbc.accelerate());
