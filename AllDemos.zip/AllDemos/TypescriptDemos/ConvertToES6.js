let y = "Hi";
function Addition(x, y) {
    return x + y;
}
