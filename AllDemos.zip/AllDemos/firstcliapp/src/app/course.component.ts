import {Component, Input} from '@angular/core';
import {Course} from './course.model';
@Component({
        selector:'app-course',
        template:`<h2> {{coursedetails.name}}</h2>
                Duration: <b> {{coursedetails.duration}} </b>
          `
})
export class CourseComponent{
    // input property
    @Input()    coursedetails:Course= new Course("Angular","5 Days") 
}