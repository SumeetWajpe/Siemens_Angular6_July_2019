import { Component } from '@angular/core';
import {Course} from './course.model';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firstcliapp';
  imageUrl:string='https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fcdn-images-1.medium.com%2Fmax%2F1600%2F1*J_-vtvcqV1-v14WqkPWhiQ.png&f=1'
  courses:Course[] = [
    new Course('React','3 Days')
,new Course('Redux','2 Days')
,new Course('Polymer','3 Days')
 ,new Course('Node','3 Days')];
}
