import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product.model';
import ProductService from '../product/product.service';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css'],
  providers:[ProductService]
  
})
export class ShoppingCartComponent implements OnInit {
 heading:string="Shopping Cart";
 newProduct:Product = new Product();
  products:Product[] = [];

  constructor(private servObj:ProductService){
      this.products = this.servObj.GetAllProducts();
  }
AddNewProduct(theForm){

  if(theForm.valid){
    if(!this.newProduct.ImageUrl){
      this.newProduct.ImageUrl = "https://cidco-smartcity.niua.org/wp-content/uploads/2017/08/No-image-found.jpg";
      this.products.push(this.newProduct);
      this.newProduct = new Product();
      theForm.reset();
    }
  }
    
        
        
}
ChangeHeading(){
  this.heading = "Flipkart !"
}




ngOnInit(){

}

  

  

}
