import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Post } from "./posts.model";
import { Observable } from "rxjs";

@Injectable()
export default class PostsService{

    constructor(public servObj:HttpClient){ }
    getAllPosts():Observable<Post[]>{
        // make an ajaxified request !
      return  this.servObj.get<Post[]>('https://jsonplaceholder.typicode.com/posts');
    }

    // getAllPosts(){
    //     // make an ajaxified request !
    //   return  this.servObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
    // }
}