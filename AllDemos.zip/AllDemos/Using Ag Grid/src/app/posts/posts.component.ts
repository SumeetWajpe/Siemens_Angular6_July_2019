import { Component, OnInit, ViewChild } from '@angular/core';
import PostsService from './posts.service';
import { Post } from './posts.model';
import { AgGridNg2 } from 'ag-grid-angular';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  allPosts:Post[] = [];
  @ViewChild('agGrid') agGrid: AgGridNg2;

  columnDefs = [
    {headerName: 'Id', field: 'id',resizable:false,checkboxSelection: true  },
    {headerName: 'Title', field: 'title',resizable:true,sortable: true, filter: true },
    {headerName: 'Body', field: 'body',resizable:true,sortable: true, filter: true}
];

  // Using Observable
  constructor(private postServObj:PostsService) {
       this.postServObj.getAllPosts().subscribe((response)=>this.allPosts = response)
   }
// using promises
// constructor(private postServObj:PostsService) {
// let thePromise =  this.postServObj.getAllPosts();
// thePromise.then(
//   function(response){
//         console.log('Promise resolved !')
//         console.log(response);
//   }
// )
// }

  ngOnInit() {
  }

  getSelectedRows() {
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map( node => node.data );
    const selectedDataStringPresentation = selectedData.map( node => node.id + ' ' + node.title).join(', ');
    alert(`Selected nodes: ${selectedDataStringPresentation}`);
}

}
