import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';

import { AppComponent } from './app.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';
import { ProductComponent } from './product/product.component';
import { QuantityPipe } from './quantity.pipe';
import { CompanyComponent } from './company/company.component';
import { CompanyService } from './company/company.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts.service';
import { PostDetailsComponent } from './post-details/post-details.component';
import { NewproductComponent } from './newproduct/newproduct.component';
import { ProductService } from './product/product.service';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGaurd } from './auth.gaurd';
import { PostsDirective } from './posts/posts.directive';
import { CourseComponent } from './course/course.component';
import { ListOfCoursesComponent } from './list-of-courses/list-of-courses.component';

// routes
// var routes:Routes = [
//   {path:'',component:ShoppingcartComponent},
//   {path:'posts',component:PostsComponent},
//   {path:'companies',component:CompanyComponent},
//   {path:'newproduct',component:NewproductComponent},
//   {path:'postdetails/:id',component:PostDetailsComponent},
//  {path:'**',redirectTo:'posts'} // or error component
// ];

var routes:Routes = [
  {path:'',component:LoginComponent},
  {
    path:'dashboard',
    component:DashboardComponent,
    children:[
      {path:'',component:ShoppingcartComponent},
      {path:'posts',component:PostsComponent},
      {path:'postdetails/:id',component:PostDetailsComponent},
      {path:'newproduct',component:NewproductComponent},
      {path:'companies',component:CompanyComponent}
    ]
    //,    canActivate:[AuthGaurd]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartComponent,
    ProductComponent,
    QuantityPipe,
    CompanyComponent,
    PostsComponent,
    PostDetailsComponent,
    NewproductComponent,
    LoginComponent,
    DashboardComponent,
    PostsDirective,CourseComponent,
    ListOfCoursesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,  
    HttpClientModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    MatCheckboxModule
  ],
  providers:[CompanyService,PostsService,ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
