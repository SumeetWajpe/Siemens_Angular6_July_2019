import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import  {ProductService} from '../product/product.service';
@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent {
heading:string=" Shopping Cart";

  allProducts:Product[] = [];
  // Using Observables
//   constructor(public prodServObj:ProductService) {
//       // this.allProducts = this.prodServObj.getAllProducts();
//      var observableProducts = this.prodServObj.getAllProducts();
//      observableProducts.subscribe((response)=>{
//         this.allProducts = response;
//  })
//    }

// Using Promises
constructor(public prodServObj:ProductService) {

}

  ChangeHeading(){
    this.heading = "Flipkart !"; // change the model !
  }

  ngOnInit(){
    if(this.prodServObj.allProductsFromService.length== 0){
      var aPromise = this.prodServObj.getAllProducts();
      aPromise.then(
        (response)=>{
          this.allProducts = response;
          this.prodServObj.allProductsFromService = response;
        } ,
        (err)=> console.log(err.status)
      )
    }
    else{
      this.allProducts = this.prodServObj.allProductsFromService;
    }
  }



}
