import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-of-courses',
  templateUrl: './list-of-courses.component.html',
  styleUrls: ['./list-of-courses.component.css']
})
export class ListOfCoursesComponent implements OnInit {


  // courses:string[]=['React'];
  inputCourse:string="Node";

  constructor() { }

  ngOnInit() {
  }

}
