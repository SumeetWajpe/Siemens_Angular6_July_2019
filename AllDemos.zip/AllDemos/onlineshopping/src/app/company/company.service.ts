export class CompanyService{
    listofcompanies:string[] = ['IBM','Siemens','Accenture','Infosys']
    getAllCompanies():string[]{
        return this.listofcompanies;
    }
    addNewCompany(newCompany:string){
        this.listofcompanies.push(newCompany)
    }
}