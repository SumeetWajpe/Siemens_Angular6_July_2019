import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

   username:string="";
   userpassword:string="";
  constructor(
    public userServObj:UserService,
    public router:Router) { }

  ngOnInit() {
  }

  Login(){
    // access username + password
    // authenticate user
    // navigate to dashboard

    if(this.username == "admin" && this.userpassword == "admin"){
          this.userServObj.setUserLoggedIn();
          this.router.navigate(['/dashboard']);
    }
  }

}
