import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
    selector:'[poststyle]'
})
export class PostsDirective{
    @Input() inputColor="yellow";
    constructor(public elemRef:ElementRef){

    }
        ngOnInit(){
            console.log(this.elemRef)
                this.elemRef.nativeElement.style.border = "2px solid red";
                this.elemRef.nativeElement.style.borderRadius = " 5px";
                this.elemRef.nativeElement.style.padding = "10px";
                this.elemRef.nativeElement.style.margin = "10px";
                this.elemRef.nativeElement.style.backgroundColor = this.inputColor;


        }
}