import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { UserService } from './user.service';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn:'root'
})
export class AuthGaurd implements CanActivate{
    constructor(
        public userServObj:UserService,
        public router:Router ){

    }    
    canActivate(
            route:ActivatedRouteSnapshot,
            state:RouterStateSnapshot
        ){
                if(!this.userServObj.getUserLoggedIn()){
                    this.router.navigate(['/']);
                }
                return this.userServObj.getUserLoggedIn();


        }
}