import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'quantity'
})
export class QuantityPipe implements PipeTransform{
        transform(theValue:number,theParameter:string){

            if(theValue == 0){
                return 'Item Out Of Stock !'
            }
                return theValue + " " + theParameter;
        }
} 