import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product/product.service';
import { Product } from '../product/product.model';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-newproduct',
  templateUrl: './newproduct.component.html',
  styleUrls: ['./newproduct.component.css']
})
export class NewproductComponent implements OnInit {
  newProduct:Product=new Product();
  constructor(public prodServObj:ProductService,
    public router:Router) { }

  ngOnInit() {
  }

  FormSubmitHandler(theForm){
   
    if(theForm.valid){
     this.prodServObj.addNewProduct(this.newProduct)
     this.newProduct = new Product();
     //theForm.reset();
      this.router.navigate(["/"]);
    } 
   }

}
