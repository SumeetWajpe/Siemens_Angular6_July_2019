import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';

@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent {
heading:string=" Shopping Cart";
  allProducts:Product[] = [  {title: 'Laptop',  price: 50000, quantity: 100, rating: 4 ,ImageUrl:'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70',likes:100 },
    { title: 'OLED TV', price: 25000, quantity: 0, rating: 3.5674,ImageUrl:'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg',likes:500 },
     { title: 'Desktop', price: 10000, quantity: 200, rating: 3,ImageUrl:'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg',likes:200   },
    { title: 'Mobile', price: 20000, quantity: 1000, rating: 5,ImageUrl:'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg' ,likes:400  },
    { title: 'Camera', price: 90000, quantity: 0, rating: 4,ImageUrl:'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png',likes:100 }
  ];
  constructor() { }

  ChangeHeading(){
    this.heading = "Flipkart !"; // change the model !
  }

  IncrementLikes(){
   
  }

}
