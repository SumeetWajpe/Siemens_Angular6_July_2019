import { Component, OnInit } from '@angular/core';
import { PostsService } from '../posts.service';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {
  allPosts:Post[]=[];
  constructor(public postsServObj:PostsService) {
     var aPromise =   this.postsServObj.getAllPosts();
     aPromise.then(
       (response)=> this.allPosts = response,
       (err)=> console.log(err)
     )
   }

  ngOnInit() {
  }

}
