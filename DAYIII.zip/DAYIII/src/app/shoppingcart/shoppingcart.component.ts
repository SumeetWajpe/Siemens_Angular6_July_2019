import { Component, OnInit } from '@angular/core';
import { Product } from '../product/product.model';
import  {ProductService} from '../product/product.service';
@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css'],
  providers:[ProductService]
})
export class ShoppingcartComponent {
heading:string=" Shopping Cart";
  allProducts:Product[] = [];
  // Using Observables
//   constructor(public prodServObj:ProductService) {
//       // this.allProducts = this.prodServObj.getAllProducts();
//      var observableProducts = this.prodServObj.getAllProducts();
//      observableProducts.subscribe((response)=>{
//         this.allProducts = response;
//  })
//    }

// Using Promises
constructor(public prodServObj:ProductService) {
  var aPromise = this.prodServObj.getAllProducts();
  aPromise.then(
    (response)=> this.allProducts = response,
    (err)=> console.log(err.status)
  )
}

  ChangeHeading(){
    this.heading = "Flipkart !"; // change the model !
  }

  IncrementLikes(){
   
  }

}
