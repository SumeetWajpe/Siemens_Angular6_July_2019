import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Post } from './posts/post.model';
import { Observable } from 'rxjs';

@Injectable()
export class PostsService{
  public allPostsFromService:Post[] = [];
    constructor(public httpServObj:HttpClient){

    }
  

    getAllPosts(){          
        return this.httpServObj.get<Post[]>("https://jsonplaceholder.typicode.com/posts").toPromise();    
    }
}