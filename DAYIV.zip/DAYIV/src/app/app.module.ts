import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';
import { ProductComponent } from './product/product.component';
import { QuantityPipe } from './quantity.pipe';
import { CompanyComponent } from './company/company.component';
import { CompanyService } from './company/company.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts.service';
import { PostDetailsComponent } from './post-details/post-details.component';
import { NewproductComponent } from './newproduct/newproduct.component';
import { ProductService } from './product/product.service';

// routes
var routes:Routes = [
  {path:'',component:ShoppingcartComponent},
  {path:'posts',component:PostsComponent},
  {path:'companies',component:CompanyComponent},
  {path:'newproduct',component:NewproductComponent},
  {path:'postdetails/:id',component:PostDetailsComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartComponent,
    ProductComponent,
    QuantityPipe,
    CompanyComponent,
    PostsComponent,
    PostDetailsComponent,
    NewproductComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,  
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers:[CompanyService,PostsService,ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
