import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Post } from '../posts/post.model';
import { PostsService } from '../posts.service';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
  thePost:Post=new Post();
  constructor(public currRoute:ActivatedRoute,
     public postServObj:PostsService) { }
  ngOnInit() {
      this.currRoute.params.subscribe(
        p=>{
          this.thePost = this.postServObj.allPostsFromService.find(post => post.id == p.id)
        }
      )
  }

}
